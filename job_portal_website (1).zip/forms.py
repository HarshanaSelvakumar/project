from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms import BooleanField, SelectField, DateField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from wtforms.widgets import TextArea
from models import User

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', 
                                     validators=[DataRequired(), EqualTo('password')])
    first_name = StringField('First Name', validators=[DataRequired()])
    last_name = StringField('Last Name', validators=[DataRequired()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already exists. Please use a different one.')

class JobSearchForm(FlaskForm):
    keyword = StringField('Keyword')
    location = StringField('Location')
    job_type = SelectField('Job Type', choices=[
        ('', 'All Types'),
        ('Full-time', 'Full-time'),
        ('Part-time', 'Part-time'),
        ('Contract', 'Contract'),
        ('Temporary', 'Temporary'),
        ('Internship', 'Internship')
    ])
    category = SelectField('Category', choices=[
        ('', 'All Categories'),
        ('IT', 'Information Technology'),
        ('Finance', 'Finance & Accounting'),
        ('Healthcare', 'Healthcare'),
        ('Education', 'Education'),
        ('Marketing', 'Marketing & Sales'),
        ('Engineering', 'Engineering'),
        ('Administrative', 'Administrative'),
        ('Customer Service', 'Customer Service'),
        ('Other', 'Other')
    ])
    submit = SubmitField('Search')

class JobApplicationForm(FlaskForm):
    job_id = HiddenField('Job ID')
    resume = TextAreaField('Resume', validators=[DataRequired()], widget=TextArea())
    cover_letter = TextAreaField('Cover Letter', widget=TextArea())
    submit = SubmitField('Apply Now')

class ProfileForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    first_name = StringField('First Name', validators=[DataRequired()])
    last_name = StringField('Last Name', validators=[DataRequired()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    bio = TextAreaField('Bio', widget=TextArea())
    submit = SubmitField('Update Profile')

class JobForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    company = StringField('Company', validators=[DataRequired()])
    location = StringField('Location', validators=[DataRequired()])
    job_type = SelectField('Job Type', choices=[
        ('Full-time', 'Full-time'),
        ('Part-time', 'Part-time'),
        ('Contract', 'Contract'),
        ('Temporary', 'Temporary'),
        ('Internship', 'Internship')
    ], validators=[DataRequired()])
    category = SelectField('Category', choices=[
        ('IT', 'Information Technology'),
        ('Finance', 'Finance & Accounting'),
        ('Healthcare', 'Healthcare'),
        ('Education', 'Education'),
        ('Marketing', 'Marketing & Sales'),
        ('Engineering', 'Engineering'),
        ('Administrative', 'Administrative'),
        ('Customer Service', 'Customer Service'),
        ('Other', 'Other')
    ], validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()], widget=TextArea())
    requirements = TextAreaField('Requirements', validators=[DataRequired()], widget=TextArea())
    salary_range = StringField('Salary Range')
    deadline = DateField('Application Deadline', format='%Y-%m-%d')
    is_active = BooleanField('Active', default=True)
    submit = SubmitField('Save Job')

class ApplicationStatusForm(FlaskForm):
    status = SelectField('Status', choices=[
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected')
    ], validators=[DataRequired()])
    feedback = TextAreaField('Feedback', widget=TextArea())
    submit = SubmitField('Update Status')
