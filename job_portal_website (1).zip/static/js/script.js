// script.js - JavaScript for JobPortal

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Add fadeIn animation to main content
    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('fadeIn');
    }
    
    // Auto-close alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Form validation enhancement
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // Toggle password visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    togglePasswordButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const passwordField = document.querySelector(this.getAttribute('data-target'));
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            
            // Toggle button icon
            const icon = this.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Character counter for text areas
    const textAreas = document.querySelectorAll('textarea[data-max-length]');
    textAreas.forEach(function(textarea) {
        const maxLength = textarea.getAttribute('data-max-length');
        const counter = document.createElement('small');
        counter.classList.add('text-muted', 'd-block', 'text-end');
        counter.textContent = `0/${maxLength} characters`;
        textarea.parentNode.insertBefore(counter, textarea.nextSibling);
        
        textarea.addEventListener('input', function() {
            const remaining = this.value.length;
            counter.textContent = `${remaining}/${maxLength} characters`;
            
            if (remaining > maxLength * 0.9) {
                counter.classList.add('text-danger');
            } else {
                counter.classList.remove('text-danger');
            }
        });
    });
    
    // Job filter form auto-submit on select change
    const filterSelects = document.querySelectorAll('.auto-submit');
    filterSelects.forEach(function(select) {
        select.addEventListener('change', function() {
            this.closest('form').submit();
        });
    });
    
    // DatePicker initialization for date inputs
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        // Set min date to today for deadline fields
        if (input.id.includes('deadline')) {
            const today = new Date().toISOString().split('T')[0];
            input.setAttribute('min', today);
        }
    });
    
    // Back to top button
    const backToTopBtn = document.createElement('button');
    backToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    backToTopBtn.classList.add('btn', 'btn-primary', 'back-to-top');
    backToTopBtn.setAttribute('title', 'Back to top');
    backToTopBtn.style.position = 'fixed';
    backToTopBtn.style.bottom = '20px';
    backToTopBtn.style.right = '20px';
    backToTopBtn.style.display = 'none';
    backToTopBtn.style.zIndex = '999';
    document.body.appendChild(backToTopBtn);
    
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({top: 0, behavior: 'smooth'});
    });
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = 'block';
        } else {
            backToTopBtn.style.display = 'none';
        }
    });
});

// Function to handle shortlisting with AJAX (if needed in the future)
function toggleShortlist(jobId, button) {
    // This is a placeholder for potential future AJAX implementation
    console.log('Toggle shortlist for job ID:', jobId);
}

// Format currency inputs
function formatCurrency(input) {
    // Remove non-numeric characters
    let value = input.value.replace(/[^\d.]/g, '');
    
    // Format with $ and commas
    if (value) {
        value = '$' + parseFloat(value).toLocaleString('en-US');
        input.value = value;
    }
}
