from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import or_, and_
from app import app, db
from models import User, Job, JobApplication, JobShortlist
from forms import (LoginForm, RegistrationForm, JobSearchForm, JobApplicationForm,
                   ProfileForm, JobForm, ApplicationStatusForm)

# Context processor to make certain variables available to all templates
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Home route
@app.route('/')
def index():
    recent_jobs = Job.query.filter_by(is_active=True).order_by(Job.posted_at.desc()).limit(5).all()
    count_jobs = Job.query.filter_by(is_active=True).count()
    count_applications = JobApplication.query.count()
    count_users = User.query.filter_by(is_admin=False).count()
    
    return render_template('index.html', 
                          recent_jobs=recent_jobs,
                          count_jobs=count_jobs,
                          count_applications=count_applications,
                          count_users=count_users)

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            flash('Login successful!', 'success')
            return redirect(next_page or url_for('index'))
        else:
            flash('Login failed. Please check your email and password.', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            phone=form.phone.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# Job routes
@app.route('/jobs', methods=['GET', 'POST'])
def jobs():
    form = JobSearchForm()
    
    if form.validate_on_submit() or request.args:
        # Get search parameters either from form submission or URL query parameters
        keyword = form.keyword.data or request.args.get('keyword', '')
        location = form.location.data or request.args.get('location', '')
        job_type = form.job_type.data or request.args.get('job_type', '')
        category = form.category.data or request.args.get('category', '')
        
        # Build the query based on search parameters
        query = Job.query.filter_by(is_active=True)
        
        if keyword:
            query = query.filter(or_(
                Job.title.ilike(f'%{keyword}%'),
                Job.description.ilike(f'%{keyword}%'),
                Job.company.ilike(f'%{keyword}%')
            ))
        
        if location:
            query = query.filter(Job.location.ilike(f'%{location}%'))
        
        if job_type:
            query = query.filter(Job.job_type == job_type)
        
        if category:
            query = query.filter(Job.category == category)
        
        # Order by most recent first
        jobs = query.order_by(Job.posted_at.desc()).all()
    else:
        # Show all active jobs if no search performed
        jobs = Job.query.filter_by(is_active=True).order_by(Job.posted_at.desc()).all()
    
    # Prepare shortlisted job IDs for the current user if logged in
    shortlisted_job_ids = []
    if current_user.is_authenticated:
        shortlisted = JobShortlist.query.filter_by(user_id=current_user.id).all()
        shortlisted_job_ids = [item.job_id for item in shortlisted]
    
    return render_template('jobs.html', jobs=jobs, form=form, shortlisted_job_ids=shortlisted_job_ids)

@app.route('/jobs/<int:job_id>')
def job_details(job_id):
    job = Job.query.get_or_404(job_id)
    
    # Check if job is shortlisted by the current user
    is_shortlisted = False
    has_applied = False
    
    if current_user.is_authenticated:
        shortlist = JobShortlist.query.filter_by(
            user_id=current_user.id, job_id=job.id
        ).first()
        is_shortlisted = shortlist is not None
        
        application = JobApplication.query.filter_by(
            user_id=current_user.id, job_id=job.id
        ).first()
        has_applied = application is not None
    
    form = JobApplicationForm()
    form.job_id.data = job.id
    
    return render_template('job_details.html', 
                          job=job, 
                          is_shortlisted=is_shortlisted,
                          has_applied=has_applied,
                          form=form)

@app.route('/apply', methods=['POST'])
@login_required
def apply_job():
    form = JobApplicationForm()
    
    if form.validate_on_submit():
        job_id = form.job_id.data
        
        # Check if job exists
        job = Job.query.get_or_404(job_id)
        
        # Check if job is still active
        if not job.is_active:
            flash('This job is no longer active.', 'warning')
            return redirect(url_for('job_details', job_id=job_id))
        
        # Check if application deadline has passed
        if job.deadline and job.deadline < datetime.utcnow().date():
            flash('The application deadline for this job has passed.', 'warning')
            return redirect(url_for('job_details', job_id=job_id))
        
        # Check if user has already applied
        existing_application = JobApplication.query.filter_by(
            user_id=current_user.id, job_id=job_id
        ).first()
        
        if existing_application:
            flash('You have already applied for this job.', 'info')
            return redirect(url_for('job_details', job_id=job_id))
        
        # Create new application
        application = JobApplication(
            user_id=current_user.id,
            job_id=job_id,
            resume=form.resume.data,
            cover_letter=form.cover_letter.data
        )
        
        db.session.add(application)
        db.session.commit()
        
        flash('Your job application has been submitted successfully!', 'success')
        return redirect(url_for('applications'))
    
    flash('There was an error with your application. Please try again.', 'danger')
    return redirect(url_for('jobs'))

@app.route('/shortlist/<int:job_id>', methods=['POST'])
@login_required
def shortlist_job(job_id):
    job = Job.query.get_or_404(job_id)
    
    # Check if already shortlisted
    existing_shortlist = JobShortlist.query.filter_by(
        user_id=current_user.id, job_id=job_id
    ).first()
    
    if existing_shortlist:
        # Remove from shortlist
        db.session.delete(existing_shortlist)
        db.session.commit()
        flash('Job removed from your shortlist.', 'info')
    else:
        # Add to shortlist
        shortlist = JobShortlist(user_id=current_user.id, job_id=job_id)
        db.session.add(shortlist)
        db.session.commit()
        flash('Job added to your shortlist.', 'success')
    
    return redirect(request.referrer or url_for('jobs'))

@app.route('/applications')
@login_required
def applications():
    applications = JobApplication.query.filter_by(user_id=current_user.id).all()
    
    return render_template('applications.html', applications=applications)

@app.route('/shortlisted')
@login_required
def shortlisted_jobs():
    form = JobSearchForm()
    shortlisted = JobShortlist.query.filter_by(user_id=current_user.id).all()
    job_ids = [item.job_id for item in shortlisted]
    jobs = Job.query.filter(Job.id.in_(job_ids)).all()
    
    # Prepare shortlisted job IDs for displaying saved jobs
    shortlisted_job_ids = [item.job_id for item in shortlisted]
    
    return render_template('jobs.html', jobs=jobs, form=form, shortlisted_job_ids=shortlisted_job_ids, is_shortlisted_page=True)

# User profile
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = ProfileForm()
    
    if request.method == 'GET':
        form.username.data = current_user.username
        form.email.data = current_user.email
        form.first_name.data = current_user.first_name
        form.last_name.data = current_user.last_name
        form.phone.data = current_user.phone
        form.bio.data = current_user.bio
    
    if form.validate_on_submit():
        # Check if username is already taken by another user
        if form.username.data != current_user.username:
            existing_user = User.query.filter_by(username=form.username.data).first()
            if existing_user:
                flash('Username already exists. Please choose a different one.', 'danger')
                return render_template('profile.html', form=form)
        
        # Check if email is already taken by another user
        if form.email.data != current_user.email:
            existing_user = User.query.filter_by(email=form.email.data).first()
            if existing_user:
                flash('Email already exists. Please use a different one.', 'danger')
                return render_template('profile.html', form=form)
        
        # Update user profile
        current_user.username = form.username.data
        current_user.email = form.email.data
        current_user.first_name = form.first_name.data
        current_user.last_name = form.last_name.data
        current_user.phone = form.phone.data
        current_user.bio = form.bio.data
        
        db.session.commit()
        flash('Your profile has been updated successfully!', 'success')
        return redirect(url_for('profile'))
    
    return render_template('profile.html', form=form)

# Admin routes
@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        abort(403)
    
    total_jobs = Job.query.count()
    active_jobs = Job.query.filter_by(is_active=True).count()
    total_applications = JobApplication.query.count()
    total_users = User.query.filter_by(is_admin=False).count()
    
    recent_applications = JobApplication.query.order_by(JobApplication.applied_at.desc()).limit(10).all()
    
    # Statistics for job applications by status
    pending_applications = JobApplication.query.filter_by(status='Pending').count()
    approved_applications = JobApplication.query.filter_by(status='Approved').count()
    rejected_applications = JobApplication.query.filter_by(status='Rejected').count()
    
    return render_template('admin/dashboard.html',
                          total_jobs=total_jobs,
                          active_jobs=active_jobs,
                          total_applications=total_applications,
                          total_users=total_users,
                          recent_applications=recent_applications,
                          pending_applications=pending_applications,
                          approved_applications=approved_applications,
                          rejected_applications=rejected_applications)

@app.route('/admin/jobs', methods=['GET', 'POST'])
@login_required
def admin_jobs():
    if not current_user.is_admin:
        abort(403)
    
    form = JobForm()
    
    if form.validate_on_submit():
        job = Job(
            title=form.title.data,
            company=form.company.data,
            location=form.location.data,
            job_type=form.job_type.data,
            category=form.category.data,
            description=form.description.data,
            requirements=form.requirements.data,
            salary_range=form.salary_range.data,
            deadline=form.deadline.data,
            is_active=form.is_active.data
        )
        
        db.session.add(job)
        db.session.commit()
        flash('New job has been added successfully!', 'success')
        return redirect(url_for('admin_jobs'))
    
    jobs = Job.query.order_by(Job.posted_at.desc()).all()
    
    return render_template('admin/jobs.html', jobs=jobs, form=form)

@app.route('/admin/jobs/edit/<int:job_id>', methods=['GET', 'POST'])
@login_required
def admin_edit_job(job_id):
    if not current_user.is_admin:
        abort(403)
    
    job = Job.query.get_or_404(job_id)
    form = JobForm()
    
    if request.method == 'GET':
        form.title.data = job.title
        form.company.data = job.company
        form.location.data = job.location
        form.job_type.data = job.job_type
        form.category.data = job.category
        form.description.data = job.description
        form.requirements.data = job.requirements
        form.salary_range.data = job.salary_range
        form.deadline.data = job.deadline
        form.is_active.data = job.is_active
    
    if form.validate_on_submit():
        job.title = form.title.data
        job.company = form.company.data
        job.location = form.location.data
        job.job_type = form.job_type.data
        job.category = form.category.data
        job.description = form.description.data
        job.requirements = form.requirements.data
        job.salary_range = form.salary_range.data
        job.deadline = form.deadline.data
        job.is_active = form.is_active.data
        
        db.session.commit()
        flash('Job has been updated successfully!', 'success')
        return redirect(url_for('admin_jobs'))
    
    return render_template('admin/jobs.html', form=form, job=job, edit_mode=True)

@app.route('/admin/jobs/delete/<int:job_id>', methods=['POST'])
@login_required
def admin_delete_job(job_id):
    if not current_user.is_admin:
        abort(403)
    
    job = Job.query.get_or_404(job_id)
    
    # Delete related applications and shortlists
    JobApplication.query.filter_by(job_id=job_id).delete()
    JobShortlist.query.filter_by(job_id=job_id).delete()
    
    db.session.delete(job)
    db.session.commit()
    
    flash('Job has been deleted successfully!', 'success')
    return redirect(url_for('admin_jobs'))

@app.route('/admin/applications')
@login_required
def admin_applications():
    if not current_user.is_admin:
        abort(403)
    
    applications = JobApplication.query.order_by(JobApplication.applied_at.desc()).all()
    
    return render_template('admin/applications.html', applications=applications)

@app.route('/admin/applications/<int:application_id>', methods=['GET', 'POST'])
@login_required
def admin_application_detail(application_id):
    if not current_user.is_admin:
        abort(403)
    
    application = JobApplication.query.get_or_404(application_id)
    form = ApplicationStatusForm()
    
    if request.method == 'GET':
        form.status.data = application.status
        form.feedback.data = application.feedback
    
    if form.validate_on_submit():
        application.status = form.status.data
        application.feedback = form.feedback.data
        application.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('Application status has been updated!', 'success')
        return redirect(url_for('admin_applications'))
    
    return render_template('admin/applications.html', 
                          application=application, 
                          form=form, 
                          detail_mode=True)

# Create admin user function - will be called with app context
def create_admin():
    # Check if admin user exists
    admin = User.query.filter_by(is_admin=True).first()
    if not admin:
        admin_user = User(
            username='admin',
            email='admin@example.com',
            first_name='Admin',
            last_name='User',
            phone='1234567890',
            is_admin=True
        )
        admin_user.set_password('admin123')  # Change in production
        db.session.add(admin_user)
        
        # Add some sample job categories
        db.session.commit()
        print("Admin user created!")
